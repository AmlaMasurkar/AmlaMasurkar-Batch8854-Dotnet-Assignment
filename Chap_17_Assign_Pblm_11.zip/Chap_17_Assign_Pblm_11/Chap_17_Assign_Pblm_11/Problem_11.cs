﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chap_17_Assign_Pblm_11
{
    class Problem_11
    {
        static void Main(string[] args)
        {
            char ch;
            int i = 1;
            int j = 0;
            while (i <= 16)
            {
                j = i + 64;
                ch = (char)j;
                Console.Write(ch);
                Console.Write(" ");
                i = i * 2;
            }
            Console.ReadKey();

        }
    }
}
