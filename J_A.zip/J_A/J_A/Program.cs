﻿using System;

namespace J_A
{
    class Program
    {
        public static void Main(string[] args)
        {
            int i, j;
            int[][] A = new int[][]
            {
                new int[]{0,1,2,3,4},
                new int[]{0,1,2,3},
                new int[]{0,1,2},
                new int[]{0,1,},
                new int[]{0},
            };
            
            for (i = 0; i < A.Length; i++)
            {
                for (j = 0; j <A[i].Length; j++)
                {
                    System.Console.Write(A[i][j] + " ");

                }
                System.Console.WriteLine();
            }
            Console.ReadLine();            
        }
    }
}
