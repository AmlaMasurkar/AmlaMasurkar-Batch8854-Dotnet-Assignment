﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chap_17_Assign_Pblm_2
{
    class Problem_02
    {
        static void Main(string[] args)
        {
            int X1, X2, X3, Y1, Y2, Y3;
            int slope1, slope2, slope3;
            ;
            Console.WriteLine("Enter the values of X1 and Y1 coordinates of 1st point");
            X1 = Convert.ToInt32(Console.ReadLine());
            Y1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the values of X2 and Y2 coordinates of 2nd point");
            X2 = Convert.ToInt32(Console.ReadLine());
            Y2 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the values of X3 and Y3 coordinates of 3rd point");
            X3 = Convert.ToInt32(Console.ReadLine());
            Y3 = Convert.ToInt32(Console.ReadLine());
            slope1 = Y2 - Y1 / X2 - X1;
            slope2 = Y3 - Y1 / X3 - X1;
            slope3 = Y3 - Y2 / X3 - X2;
            if (slope1 == slope2 && slope1 == slope3)
            {
                Console.WriteLine("\nAll points are falling on one straight line. ");
            }
            else
            {
                Console.WriteLine("\nAll points are not falling on one straight line");
            }
            Console.ReadKey();

        }
    }
}
