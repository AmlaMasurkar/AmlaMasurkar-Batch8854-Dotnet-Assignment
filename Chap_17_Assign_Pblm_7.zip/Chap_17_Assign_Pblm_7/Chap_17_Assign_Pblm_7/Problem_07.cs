﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chap_17_Assign_Pblm_7
{
    class Problem_07
    {
        static void Main(string[] args)
        {
            int Year;
            string a;
            Console.WriteLine("Enter a Year:");
            Year = Convert.ToInt32(Console.ReadLine());
            a = Year % 4 == 0 ? "Year Is Leap" : "It Is Not A Leap Year:";
            Console.WriteLine(a);
            Console.ReadKey();
        }
    }
}
