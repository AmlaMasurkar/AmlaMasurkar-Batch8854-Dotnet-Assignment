﻿using System;

namespace As_Operator
{
    public class Demo
    {
        public static void Main()
        {
            Object[] Obj = new Object[7];
            Obj[0] = "Amla";
            Obj[1] = "88";
            Obj[2] = ".Net";
            Obj[3] = "$@%";
            Obj[4] = "'Data_structures'";
       
            for (int i = 0; i < Obj.Length; ++i)
            {
                string S = Obj[i] as string;
                Console.Write("{0}:", i);
                if (S != null)
                    Console.WriteLine("'" + S + "'");
                else
                    Console.WriteLine("This is not a String!!!");
            }
            Console.ReadKey();
        }


    }
}
