﻿using System;

namespace Is_Operator
{
    class One { }
    class Two
    {
        public class Demo
        {
            public static void Test(object obj)
            {
                One a;
                Two b;
                if (obj is One)
                {
                    Console.WriteLine("Class 1");
                    a = (One)obj;
                }
                else if (obj is Two)
                {
                    Console.WriteLine("Class 2");
                    b = (Two)obj;
                }
                else
                {
                    Console.WriteLine("None of the Classes");
                }
            }
            static void Main(string[] args)
            {
                One O = new One();
                Two T = new Two();
                Test(O);
                Test(T);
                Test("str");
                Console.ReadKey();
            }
        }
    }
}

