﻿using System;
using System.Text;

namespace Get_Hash_Code
{
    class Program
    {
        class HashC
        {
            string name;
            int Marks;
            public HashC(string name)
            {
                this.name = name;
            }
            
            public override int GetHashCode()
            {
                string n = ToString();                
                return base.GetHashCode();                 
            }
        }
        static void Main(string[] args)
        {
            HashC HC = new HashC("Amla Manoj Masurkar"); 
            Console.WriteLine(HC.GetHashCode());

            Console.ReadLine();
        }
    }
}
