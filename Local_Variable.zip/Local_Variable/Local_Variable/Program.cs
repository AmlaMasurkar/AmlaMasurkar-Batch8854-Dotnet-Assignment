﻿using System;

namespace Local_Variable
{
    class ImplicitTypedExample
    {
        public static void Main()
        {

            var A = 100;
            
            var M = ".NET Developer";

            var arr = new[] { 1, 2, 3, 8, 10, 15, 25 };
            Console.WriteLine(A);
            Console.WriteLine(M);
            Console.WriteLine(arr[5]);

        }
    }
} 