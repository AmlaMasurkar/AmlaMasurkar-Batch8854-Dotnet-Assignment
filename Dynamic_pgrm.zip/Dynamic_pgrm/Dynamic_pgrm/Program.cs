﻿using System;

namespace Dynamic_pgrm
{
    class Demo
    {
        dynamic Value = 150;
        public float Method(float A, float B)
        {
            return (A * Value + B) / Value;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Demo Obj = new Demo();
            dynamic X;
            dynamic Y;
            Console.WriteLine("Enter A:") ;
            X = Console.ReadLine();
            float A = float.Parse(X);
            Console.WriteLine("Enter B:");
            Y = Console.ReadLine();
            float B = float.Parse(Y);          
            Console.WriteLine("The Result is:" + Obj.Method(A, B));
            Console.ReadLine();
        }
    }
}
