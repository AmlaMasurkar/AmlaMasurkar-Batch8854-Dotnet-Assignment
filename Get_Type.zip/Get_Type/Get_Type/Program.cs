﻿using System;
using System.Text;

namespace Get_Type
{
    class Program
    {
        static void Main(string[] args)
        {
            Object Obj = new Object();
            System.String s1 = "Testing object"; 
            Type type1 = 
            Obj.GetType(); Type type2 = s1.GetType();
            Console.WriteLine(type1.BaseType); 
            Console.WriteLine(type1.Name); 
            Console.WriteLine(type1.FullName); 
            Console.WriteLine(type1.Namespace); 
            Console.WriteLine();

            Console.WriteLine(type2.BaseType); 
            Console.WriteLine(type2.Name); 
            Console.WriteLine(type2.FullName); 
            Console.WriteLine(type2.Namespace); 
            Console.ReadLine();
        }
    }
}
