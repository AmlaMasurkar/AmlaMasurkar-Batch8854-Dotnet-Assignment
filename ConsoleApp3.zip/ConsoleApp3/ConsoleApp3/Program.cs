﻿using System;

namespace ConsoleApp3
{
    class Program
    {
        public static void Main(string[] args)
        {
            int i, j;
            int[,] A = new int[3, 3];
            Console.WriteLine("Enter elements for 3*3 Matrix:...");
            for (i = 0; i < 3; i++)
            {
                for (j = 0; j < 3; j++)
                {
                    Console.Write("Enter element at A[{0},{1}] = ", i, j);
                    A[i, j] = Convert.ToInt32(Console.ReadLine());

                }
            }
            for (i = 0; i < 3; i++)
            {
                Console.Write("\n");
                for (j = 0; j < 3; j++)
                {
                    Console.Write("{0}\t",A[i,j]);                
                }
            }
        }
    }
}
