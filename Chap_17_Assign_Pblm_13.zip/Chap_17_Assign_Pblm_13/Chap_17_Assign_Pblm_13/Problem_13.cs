﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chap_17_Assign_Pblm_13
{
    class Problem_13
    {
        static void Main(string[] args)
        {
            char ch;
            int i = 0;
            while (i <= 255)
            {
                Console.Write(i);
                Console.Write(" ");
                ch = (char)i;
                Console.WriteLine(ch);
                i++;
            }
            Console.ReadKey();
        }
    }
}
