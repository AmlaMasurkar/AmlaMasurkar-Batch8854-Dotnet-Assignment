﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chap_17_Assign_Pblm_6
{
    class Problem_06
    {
        static void Main(string[] args)
        {
            int TIME;
            Console.WriteLine("Enter TIME Required For A Worker To Complete A Particular Job In Hours");
            TIME = Convert.ToInt32(Console.ReadLine());
            if (TIME >= 2 && TIME >= 3)
            {
                Console.WriteLine("Worker Efficiency Is Highly Efficient.");
            }
            if (TIME >= 3 && TIME >= 4)
            {
                Console.WriteLine("Worker Should Improve His Speed.");
            }
            if (TIME >= 4 && TIME >= 5)
            {
                Console.WriteLine("Worker Is Given Training To Improve His Speed.");
            }
            if (TIME > 5)
            {
                Console.WriteLine("Worker Should Leave The Company.");
            }
            Console.ReadKey();
        }
    }
}
