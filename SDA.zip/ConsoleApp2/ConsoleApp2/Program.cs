﻿using System;

namespace S_D_A
{
    class Program
    {
        public static void Main(string[] args)
        {
            int[] A = new int[] { 10, 11, 12, 13, 14, 15 };
            for (int i = 0; i < A.Length; i++)
            {
                Console.WriteLine(A[i]);
            }
            Console.ReadLine();
        }
    }
}
