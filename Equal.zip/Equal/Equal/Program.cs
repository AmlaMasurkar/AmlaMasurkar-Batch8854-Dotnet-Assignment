﻿using System;
using System.Text;

namespace Equal
{
    class Program
    {
        public class Class1 : Object
        {
            public void Method1()
            {
                Console.WriteLine("Method 1");
            }
        }
        public class Class2 : Object
        {
            public void Method1()
            {
                Console.WriteLine("Method 2");
            }
        }
        static void Main(string[] args)
        {
            Class1 ob1 = new Class1(); 
            Class2 ob2 = new Class2(); 
            string s1 = "String"; 
            string s2 = "String"; 
            Console.WriteLine("Comparision of two object"); 
            Console.WriteLine(Object.Equals(ob1, ob2)); 
            Console.WriteLine(Object.Equals(s1, s2)); 
            Console.WriteLine(Object.ReferenceEquals(ob1, ob2)); 
            Console.WriteLine(Object.ReferenceEquals(ob2, ob2)); 
            Console.WriteLine(Object.ReferenceEquals(s1, s2)); 
            Console.ReadLine();
        }
    }
}
