﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chap_17_Assign_Pblm_1
{
    class Problem_01
    {
        static void Main(string[] args)
        {
            char a;
            int b;
            ;
            Console.WriteLine("Enter a Letter Between a-z:");
            a = Convert.ToChar(Console.ReadLine());
            b = (int)a;
            if (b >= 97 &&  b <= 122)
            {
                b = b - 32;
                a = (char)b;
                Console.WriteLine("In Upper Case Letter:" + a);
            }
            else
            {
                Console.WriteLine("You Enter Wrong Letter, Please Enter Letter Between a-z....!");
            }
            Console.ReadKey();
        }
    }
}
