﻿using System.IO;
using System;

namespace out_and_ref
{
    public class Program
    {
        public static void update(out int A)
        {
            A = 100;
        }
        public static void change(ref int D)
        {
            D = 1000;
        }
        public static void Main()
        {
            int B; 
            int C = 9; 
            Program p1 = new Program(); 
            update(out B); 
            change(ref C); 
            Console.WriteLine("Updated value is: {0}", B); 
            Console.WriteLine("Changed value is: {0}", C);
        }
    }
}
