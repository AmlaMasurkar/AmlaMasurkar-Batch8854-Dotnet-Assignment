﻿using System;
using System.Text;

namespace To_String
{
    class Program
    {
        static void Main(string[] args)
        {
            string Name = "Amla Manoj Masurkar";
            int Age = 22;
            float CGPA = 7.25f;

            Console.WriteLine(Name);
            Console.WriteLine(Age.ToString());
            Console.WriteLine(CGPA.ToString());
            Console.ReadLine();
        }
    }
}
